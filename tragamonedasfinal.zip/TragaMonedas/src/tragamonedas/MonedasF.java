
package tragamonedas;

import java.awt.Color;
import java.awt.Image;
import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class MonedasF extends javax.swing.JDialog {

    
    public MonedasF(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
       
    }
   int contador = 0, conta2 = 0, contador3 =0, contador4 = 0;
   

    

                   
   public class casilla1 extends Thread{
    
        @Override
        public void run(){
            
            while(BUTTON.isSelected() == true){
            
                Random r = new Random(); 
            
                contador = r.nextInt(6)+1;
        
            ImageIcon img;
            ImageIcon escala1;
            Image mesa; 
            
            switch (contador) {
            case 1:
                
                img = new ImageIcon(getClass().getResource("7.png"));
                mesa = img.getImage();
                escala1 = new ImageIcon(mesa.getScaledInstance(
                        cas1.getWidth(), cas1.getHeight(), java.awt.Image.SCALE_SMOOTH));
                cas1.setIcon(escala1);
                break;
                
            case 2:
                
                img = new ImageIcon(getClass().getResource("cerezas.png"));
                mesa = img.getImage();
                escala1 = new ImageIcon(mesa.getScaledInstance(
                        cas1.getWidth(), cas1.getHeight(), java.awt.Image.SCALE_SMOOTH));
                cas1.setIcon(escala1);
                break;
            
            case 3:
                img = new ImageIcon(getClass().getResource("diamante.png"));
                mesa = img.getImage();
                escala1 = new ImageIcon(mesa.getScaledInstance(
                        cas1.getWidth(), cas1.getHeight(), java.awt.Image.SCALE_SMOOTH));
                cas1.setIcon(escala1);
                break;
                
            case 4:
                img = new ImageIcon(getClass().getResource("limon.png"));
                mesa = img.getImage();
                escala1 = new ImageIcon(mesa.getScaledInstance(
                        cas1.getWidth(), cas1.getHeight(), java.awt.Image.SCALE_SMOOTH));
                cas1.setIcon(escala1);
                break;
      
            }  
            try{
                Thread.sleep(30);
            }catch (InterruptedException e){
                e.printStackTrace();
            }
        }
        }
    }
  public class casilla2 extends Thread{
    
        @Override
        public void run(){
            
            while(BUTTON.isSelected() == true){
            
                Random r = new Random(); 
            
                conta2 = r.nextInt(6)+1;
        
            ImageIcon img;
            ImageIcon escala1;
            Image mesa; 
            
            switch (conta2) {
            case 1:
                
                img = new ImageIcon(getClass().getResource("7.png"));
                mesa = img.getImage();
                escala1 = new ImageIcon(mesa.getScaledInstance(
                        cas2.getWidth(), cas2.getHeight(), java.awt.Image.SCALE_SMOOTH));
                cas2.setIcon(escala1);
                break;
                
            case 2:
                
                img = new ImageIcon(getClass().getResource("cerezas.png"));
                mesa = img.getImage();
                escala1 = new ImageIcon(mesa.getScaledInstance(
                        cas2.getWidth(), cas2.getHeight(), java.awt.Image.SCALE_SMOOTH));
                cas2.setIcon(escala1);
                break;
            
            case 3:
               img = new ImageIcon(getClass().getResource("diamante.png"));
                mesa = img.getImage();
                escala1 = new ImageIcon(mesa.getScaledInstance(
                        cas2.getWidth(), cas2.getHeight(), java.awt.Image.SCALE_SMOOTH));
                cas2.setIcon(escala1);
                break;
                
            case 4:
                img = new ImageIcon(getClass().getResource("limon.png"));
                mesa = img.getImage();
                escala1 = new ImageIcon(mesa.getScaledInstance(
                        cas2.getWidth(), cas2.getHeight(), java.awt.Image.SCALE_SMOOTH));
                cas2.setIcon(escala1);
                break;
          
        }
            try{
                Thread.sleep(30);
            }catch (InterruptedException e){
                e.printStackTrace();
            }
        }
        }
    }
  public class casilla3 extends Thread{
    
        @Override
        public void run(){
            
            while(BUTTON.isSelected() == true){
            
                Random r = new Random(); 
            
                contador3 = r.nextInt(6)+1;
        
            ImageIcon img;
            ImageIcon escala1;
            Image mesa; 
            
            switch (contador3) {
            case 1:
                
                img = new ImageIcon(getClass().getResource("7.png"));
                mesa = img.getImage();
                escala1 = new ImageIcon(mesa.getScaledInstance(
                        cas3.getWidth(), cas3.getHeight(), java.awt.Image.SCALE_SMOOTH));
                cas3.setIcon(escala1);
                break;
                
            case 2:
                
                img = new ImageIcon(getClass().getResource("cerezas.png"));
                mesa = img.getImage();
                escala1 = new ImageIcon(mesa.getScaledInstance(
                        cas3.getWidth(), cas3.getHeight(), java.awt.Image.SCALE_SMOOTH));
                cas3.setIcon(escala1);
                break;
            
            case 3:
               img = new ImageIcon(getClass().getResource("diamante.png"));
                mesa = img.getImage();
                escala1 = new ImageIcon(mesa.getScaledInstance(
                        cas3.getWidth(), cas3.getHeight(), java.awt.Image.SCALE_SMOOTH));
                cas3.setIcon(escala1);
                break;
                
            case 4:
                img = new ImageIcon(getClass().getResource("limon.png"));
                mesa = img.getImage();
                escala1 = new ImageIcon(mesa.getScaledInstance(
                        cas3.getWidth(), cas3.getHeight(), java.awt.Image.SCALE_SMOOTH));
                cas3.setIcon(escala1);
                break;
 
        }
            try{
                Thread.sleep(30);
            }catch (InterruptedException e){
                e.printStackTrace();
            }
        }
        }
    }
  public class casilla4 extends Thread{
    
        @Override
        public void run(){
            
            while(BUTTON.isSelected() == true){
            
                Random r = new Random(); 
            
                contador4 = r.nextInt(6)+1;
        
            ImageIcon img;
            ImageIcon escala1;
            Image mesa; 
            
            switch (contador4) {
            case 1:
                
                img = new ImageIcon(getClass().getResource("7.png"));
                mesa = img.getImage();
                escala1 = new ImageIcon(mesa.getScaledInstance(
                        cas4.getWidth(), cas4.getHeight(), java.awt.Image.SCALE_SMOOTH));
                cas4.setIcon(escala1);
                break;
                
            case 2:
                
                img = new ImageIcon(getClass().getResource("cerezas.png"));
                mesa = img.getImage();
                escala1 = new ImageIcon(mesa.getScaledInstance(
                        cas4.getWidth(), cas4.getHeight(), java.awt.Image.SCALE_SMOOTH));
                cas4.setIcon(escala1);
                break;
            
            case 3:
               img = new ImageIcon(getClass().getResource("diamante.png"));
                mesa = img.getImage();
                escala1 = new ImageIcon(mesa.getScaledInstance(
                        cas4.getWidth(), cas4.getHeight(), java.awt.Image.SCALE_SMOOTH));
                cas4.setIcon(escala1);
                break;
                
            case 4:
                img = new ImageIcon(getClass().getResource("limon.png"));
                mesa = img.getImage();
                escala1 = new ImageIcon(mesa.getScaledInstance(
                        cas4.getWidth(), cas4.getHeight(), java.awt.Image.SCALE_SMOOTH));
                cas4.setIcon(escala1);
                break;
                
       
        }
            try{
                Thread.sleep(30);
            }catch (InterruptedException e){
                e.printStackTrace();
            }
        }
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        si = new javax.swing.JPanel();
        BUTTON = new javax.swing.JToggleButton();
        cas4 = new javax.swing.JLabel();
        cas3 = new javax.swing.JLabel();
        cas2 = new javax.swing.JLabel();
        cas1 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        si.setBackground(new java.awt.Color(102, 0, 0));

        BUTTON.setText("START");
        BUTTON.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BUTTONActionPerformed(evt);
            }
        });

        jLabel1.setBackground(new java.awt.Color(51, 0, 255));
        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setText("JACKPOT");

        javax.swing.GroupLayout siLayout = new javax.swing.GroupLayout(si);
        si.setLayout(siLayout);
        siLayout.setHorizontalGroup(
            siLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(siLayout.createSequentialGroup()
                .addGroup(siLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(siLayout.createSequentialGroup()
                        .addGap(183, 183, 183)
                        .addComponent(BUTTON, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(siLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(cas1, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(27, 27, 27)
                        .addComponent(cas2, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(36, 36, 36)
                        .addComponent(cas3, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30)
                        .addComponent(cas4, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(siLayout.createSequentialGroup()
                        .addGap(296, 296, 296)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(95, Short.MAX_VALUE))
        );
        siLayout.setVerticalGroup(
            siLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, siLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(siLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(siLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(cas1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(cas2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(cas4, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(cas3, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(BUTTON, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(si, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(si, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BUTTONActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BUTTONActionPerformed
        Thread girar1 = new MonedasF.casilla1(); 
        Thread girar2 = new MonedasF.casilla2(); 
        Thread girar3 = new MonedasF.casilla3(); 
        Thread girar4 = new MonedasF.casilla4(); 
        
        if (BUTTON.isSelected()) {
             
             BUTTON.setText("PARAR");
             BUTTON.setBackground(Color.RED);
             girar1.start();
             girar2.start();
             girar3.start();
             girar4.start();
            
        }else{
             
             BUTTON.setText("INICIAR");
             BUTTON.setBackground(Color.GREEN);
             girar1.stop();
             girar2.stop();
             girar3.stop();
             girar4.stop();
             if (contador3 == contador && conta2 == contador4) {
                JOptionPane.showMessageDialog(null,"WINNER WINNER, CHICKEN DINNER");
            }else{
                 JOptionPane.showMessageDialog(null,"SIGA INTENTANDO");
             }

        }
    }//GEN-LAST:event_BUTTONActionPerformed

    
    public static void main(String args[]) {
    
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                MonedasF dialog = new MonedasF(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JToggleButton BUTTON;
    private javax.swing.JLabel cas1;
    private javax.swing.JLabel cas2;
    private javax.swing.JLabel cas3;
    private javax.swing.JLabel cas4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel si;
    // End of variables declaration//GEN-END:variables
}
