
package tragamonedas;


public class TragaMonedas {

    public static void main(String[] args) {
        
    }
    
}
