

package tragamonedas;

import java.awt.Color;
import java.awt.Image;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;


public class DadosF extends javax.swing.JDialog {

    public DadosF(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        

        
    }
    
    int contador = 0, conta2 = 0;
    public class dado extends Thread{
    
        @Override
        public void run(){
            
            while(BUTTON.isSelected() == true){
            
                Random r = new Random(); 
            
                contador = r.nextInt(6)+1;
        
            ImageIcon img;
            ImageIcon escala1;
            Image mesa; 
            
            switch (contador) {
            case 1:
                
                img = new ImageIcon(getClass().getResource("dado1.png"));
                mesa = img.getImage();
                escala1 = new ImageIcon(mesa.getScaledInstance(
                        dado1.getWidth(), dado1.getHeight(), java.awt.Image.SCALE_SMOOTH));
                dado1.setIcon(escala1);
                break;
                
            case 2:
                
                img = new ImageIcon(getClass().getResource("dado2.png"));
                mesa = img.getImage();
                escala1 = new ImageIcon(mesa.getScaledInstance(
                        dado1.getWidth(), dado1.getHeight(), java.awt.Image.SCALE_SMOOTH));
                dado1.setIcon(escala1);
                break;
            
            case 3:
                img = new ImageIcon(getClass().getResource("dado3.png"));
                mesa = img.getImage();
                escala1 = new ImageIcon(mesa.getScaledInstance(
                        dado1.getWidth(), dado1.getHeight(), java.awt.Image.SCALE_SMOOTH));
                dado1.setIcon(escala1);
                break;
                
            case 4:
                img = new ImageIcon(getClass().getResource("dado4.png"));
                mesa = img.getImage();
                escala1 = new ImageIcon(mesa.getScaledInstance(
                        dado1.getWidth(), dado1.getHeight(), java.awt.Image.SCALE_SMOOTH));
                dado1.setIcon(escala1);
                break;
                
            case 5:
                img = new ImageIcon(getClass().getResource("dado5.png"));
                mesa = img.getImage();
                escala1 = new ImageIcon(mesa.getScaledInstance(
                        dado1.getWidth(), dado1.getHeight(), java.awt.Image.SCALE_SMOOTH));
                dado1.setIcon(escala1);
                break;
            
            case 6:
                img = new ImageIcon(getClass().getResource("dado6.png"));
                mesa = img.getImage();
                escala1 = new ImageIcon(mesa.getScaledInstance(
                        dado1.getWidth(), dado1.getHeight(), java.awt.Image.SCALE_SMOOTH));
                dado1.setIcon(escala1);
                break;
        }
            try{
                Thread.sleep(30);
            }catch (InterruptedException e){
                e.printStackTrace();
            }
        }
        }
    }
    
public class dado2 extends Thread{
    
        @Override
        public void run(){
           while(BUTTON.isSelected() == true){
            Random r2 = new Random(); 
            conta2 = r2.nextInt(6)+1;
        
            ImageIcon img;
            ImageIcon escala1;
            Image mesa; 
            
      
            switch (conta2) {
            case 1:
                
                img = new ImageIcon(getClass().getResource("dado1.png"));
                mesa = img.getImage();
                escala1 = new ImageIcon(mesa.getScaledInstance(
                        dado2.getWidth(), dado2.getHeight(), java.awt.Image.SCALE_SMOOTH));
                dado2.setIcon(escala1);
                break;
                
            case 2:
                
                
                img = new ImageIcon(getClass().getResource("dado2.png"));
                mesa = img.getImage();
                escala1 = new ImageIcon(mesa.getScaledInstance(
                        dado2.getWidth(), dado2.getHeight(), java.awt.Image.SCALE_SMOOTH));
                dado2.setIcon(escala1);
                break;
            
            case 3:
                               
                img = new ImageIcon(getClass().getResource("dado3.png"));
                mesa = img.getImage();
                escala1 = new ImageIcon(mesa.getScaledInstance(
                        dado2.getWidth(), dado2.getHeight(), java.awt.Image.SCALE_SMOOTH));
                dado2.setIcon(escala1);
                break;
                
            case 4:
                               
                img = new ImageIcon(getClass().getResource("dado4.png"));
                mesa = img.getImage();
                escala1 = new ImageIcon(mesa.getScaledInstance(
                        dado2.getWidth(), dado2.getHeight(), java.awt.Image.SCALE_SMOOTH));
                dado2.setIcon(escala1);
                break;
                
            case 5:
                               
                img = new ImageIcon(getClass().getResource("dado5.png"));
                mesa = img.getImage();
                escala1 = new ImageIcon(mesa.getScaledInstance(
                        dado2.getWidth(), dado2.getHeight(), java.awt.Image.SCALE_SMOOTH));
                dado2.setIcon(escala1);
                break;
            
            case 6:
                               
                img = new ImageIcon(getClass().getResource("dado6.png"));
                mesa = img.getImage();
                escala1 = new ImageIcon(mesa.getScaledInstance(
                        dado2.getWidth(), dado2.getHeight(), java.awt.Image.SCALE_SMOOTH));
                dado2.setIcon(escala1);
                break;
        }
            try{
                Thread.sleep(30);
            }catch (InterruptedException e){
                e.printStackTrace();
            }
           }
        }
    }
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panel = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        BUTTON = new javax.swing.JToggleButton();
        jLabel1 = new javax.swing.JLabel();
        dado1 = new javax.swing.JLabel();
        dado2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("DADOS");
        setBackground(new java.awt.Color(0, 51, 51));

        panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 51, 51));

        BUTTON.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N
        BUTTON.setText("INICIAR");
        BUTTON.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BUTTONActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("JUEGO DE DADOS");

        dado1.setBackground(new java.awt.Color(204, 204, 0));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(dado1, javax.swing.GroupLayout.PREFERRED_SIZE, 336, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                        .addGap(275, 275, 275)
                        .addComponent(BUTTON)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(dado2, javax.swing.GroupLayout.PREFERRED_SIZE, 331, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(231, 231, 231))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(dado2, javax.swing.GroupLayout.DEFAULT_SIZE, 287, Short.MAX_VALUE)
                    .addComponent(dado1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(BUTTON)
                .addContainerGap(38, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(223, 223, 223)
                .addComponent(panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BUTTONActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BUTTONActionPerformed
        
        Thread girar1 = new dado(); 
        Thread girar2 = new dado2(); 
        
        if (BUTTON.isSelected()) {
             
             BUTTON.setText("PARAR");
             BUTTON.setBackground(Color.RED);
             girar1.start();
             girar2.start();
            
        }else{
             
             BUTTON.setText("INICIAR");
             BUTTON.setBackground(Color.GREEN);
             girar1.stop();
             girar2.stop();
             if (contador == conta2) {
                JOptionPane.showMessageDialog(null,"WINNER WINNER, CHICKEN DINNER");
            }else{
                 JOptionPane.showMessageDialog(null,"SIGA INTENTANDO");
             }

        }
    }//GEN-LAST:event_BUTTONActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DadosF.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DadosF.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DadosF.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DadosF.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                DadosF dialog = new DadosF(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JToggleButton BUTTON;
    private javax.swing.JLabel dado1;
    private javax.swing.JLabel dado2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel panel;
    // End of variables declaration//GEN-END:variables

}
